## Installation

```bash
pip install dsf
```

## Usage

```
